import { CalendarClock, CheckCircle2, FileText, TrendingUp, Wallet } from 'lucide-react';
import { PageHeader } from '@/components/ui/PageHeader';
import { FinanceCard } from '@/components/finance/FinanceCard';
import { FinanceTable, TotalCell } from '@/components/finance/FinanceTable';
import { Pill, Section } from '@/components/finance/Controls';
import { CardGridSkeleton, ErrorState, TableSkeleton } from '@/components/finance/States';
import { ProgressBar } from '@/components/charts/CircularProgress';
import {
  getInvestmentTimeline,
  type InvestmentTimeline,
  type TimelineEntry,
} from '@/lib/investorFinanceApi';
import { useInvestorData } from './useInvestorData';
import { formatDate, humanize, inr, percent } from '@/lib/format';

/**
 * ============================================================================
 *  2. INVESTMENT TIMELINE
 * ============================================================================
 *
 * Every rupee paid in, in order, with the equity each payment bought.
 *
 * The "Ownership earned" column is the point of this page. An investor who
 * pays ₹15,000 and then ₹1,532 should be able to see that those two payments
 * bought 1.5% and 0.1532%, and that the two add up to the 1.6532% shown on
 * their dashboard. If that reconciliation is not visible, the headline number
 * is just a number they have to take on trust.
 * ============================================================================
 */

export default function InvestorTimeline() {
  const { data, loading, error, reload } = useInvestorData<InvestmentTimeline>(
    () => getInvestmentTimeline(),
    [],
  );

  if (loading) {
    return (
      <div className="space-y-6">
        <PageHeader eyebrow="Investment" title="Investment timeline" />
        <CardGridSkeleton />
        <TableSkeleton />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div>
        <PageHeader eyebrow="Investment" title="Investment timeline" />
        <ErrorState message={error ?? 'No data was returned.'} onRetry={reload} />
      </div>
    );
  }

  const { summary, entries, commitments } = data;

  return (
    <div className="space-y-7">
      <PageHeader
        eyebrow="Investment"
        title="Investment timeline"
        subtitle="Every payment you have made, and the ownership each one unlocked."
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <FinanceCard
          icon={Wallet}
          label="Total invested"
          value={summary.totalInvested}
          format={inr}
          hint={`across ${summary.paymentCount} payment${summary.paymentCount === 1 ? '' : 's'}`}
          tone="brand"
        />
        <FinanceCard
          icon={CalendarClock}
          label="Committed"
          value={summary.committedInvestment}
          format={inr}
          hint={
            summary.isFullyFunded
              ? 'Fully funded'
              : `${inr(summary.remainingInvestment)} outstanding`
          }
          tone={summary.isFullyFunded ? 'green' : 'amber'}
        />
        <FinanceCard
          icon={TrendingUp}
          label="Ownership earned"
          value={summary.ownershipPercent}
          format={(value) => percent(value)}
          hint={`of ${percent(summary.agreedOwnershipPercent, 2)} agreed`}
          tone="violet"
        />
        <FinanceCard
          icon={CheckCircle2}
          label="Funding progress"
          value={summary.progressPercent}
          format={(value) => percent(value, 2)}
          tone="sky"
          progress={summary.progressPercent}
        />
      </div>

      {/* ----------------------------- commitments ---------------------------- */}
      {commitments.length > 0 && (
        <Section
          title="Commitments"
          description="Each commitment vests independently against its own agreed equity."
        >
          <div className="grid gap-4 lg:grid-cols-2">
            {commitments.map((commitment) => (
              <div key={commitment.commitmentId} className="glass-card p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="truncate text-sm font-semibold text-white">
                      {commitment.title}
                    </h3>
                    <p className="mt-1 text-xs text-slate-400">
                      Started {formatDate(commitment.startDate)} ·{' '}
                      {humanize(commitment.investmentType)}
                    </p>
                  </div>
                  <Pill tone={commitment.isFullyFunded ? 'green' : 'amber'}>
                    {commitment.isFullyFunded ? 'Fully funded' : humanize(commitment.status)}
                  </Pill>
                </div>

                <dl className="mt-4 grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <dt className="text-xs text-slate-500">Received</dt>
                    <dd className="mt-0.5 font-semibold tabular-nums text-white">
                      {inr(commitment.receivedTotal)}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-slate-500">Committed</dt>
                    <dd className="mt-0.5 font-semibold tabular-nums text-white">
                      {inr(commitment.committedAmount)}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-slate-500">Ownership now</dt>
                    <dd className="mt-0.5 font-semibold tabular-nums text-violet-300">
                      {percent(commitment.ownershipPercent)}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-slate-500">Agreed at full funding</dt>
                    <dd className="mt-0.5 font-semibold tabular-nums text-white">
                      {percent(commitment.agreedOwnershipPercent, 2)}
                    </dd>
                  </div>
                </dl>

                <div className="mt-4">
                  <ProgressBar
                    value={commitment.fundingProgressPercent}
                    showLabel
                    label="Funding progress"
                  />
                </div>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* ------------------------------- payments ------------------------------ */}
      <Section
        title="Payments"
        description="Ownership earned per payment adds up to your total ownership."
      >
        <FinanceTable<TimelineEntry>
          rows={entries}
          rowKey={(row) => row.investmentId}
          emptyTitle="No payments recorded yet"
          emptyMessage="Once your first capital payment is recorded, it will appear here with the ownership it earned."
          columns={[
            {
              key: 'date',
              header: 'Date',
              render: (row) => (
                <span className="whitespace-nowrap text-slate-300">{formatDate(row.date)}</span>
              ),
            },
            {
              key: 'amount',
              header: 'Amount',
              numeric: true,
              render: (row) => (
                <span className="font-semibold text-white">{inr(row.amount)}</span>
              ),
            },
            {
              key: 'commitment',
              header: 'Commitment',
              hideOnMobile: true,
              render: (row) => (
                <span className="text-slate-400">{row.commitmentTitle ?? 'Direct investment'}</span>
              ),
            },
            {
              key: 'cumulative',
              header: 'Total invested',
              numeric: true,
              hideOnMobile: true,
              render: (row) => (
                <span className="text-slate-300">{inr(row.cumulativeInvested)}</span>
              ),
            },
            {
              key: 'earned',
              header: 'Ownership earned',
              numeric: true,
              render: (row) => (
                <span className="font-semibold text-violet-300">
                  +{percent(row.ownershipEarned)}
                </span>
              ),
            },
            {
              key: 'running',
              header: 'Ownership after',
              numeric: true,
              hideOnMobile: true,
              render: (row) => (
                <span className="text-slate-300">{percent(row.cumulativeOwnership)}</span>
              ),
            },
            {
              key: 'progress',
              header: 'Progress',
              hideOnMobile: true,
              width: '140px',
              render: (row) => (
                <div className="flex items-center gap-2">
                  <ProgressBar value={row.progressPercent} height={5} />
                  <span className="w-12 shrink-0 text-right text-[11px] tabular-nums text-slate-500">
                    {percent(row.progressPercent, 1)}
                  </span>
                </div>
              ),
            },
            {
              key: 'status',
              header: 'Status',
              align: 'center',
              render: (row) => (
                <Pill tone="green">
                  <CheckCircle2 className="h-3 w-3" />
                  {humanize(row.status)}
                </Pill>
              ),
            },
            {
              key: 'invoice',
              header: 'Invoice',
              align: 'center',
              hideOnMobile: true,
              render: (row) =>
                row.hasInvoice ? (
                  <FileText className="mx-auto h-4 w-4 text-brand-300" aria-label="Invoice attached" />
                ) : (
                  <span className="text-slate-600">—</span>
                ),
            },
          ]}
          footer={
            <>
              <TotalCell numeric={false}>Total</TotalCell>
              <TotalCell>{inr(summary.totalInvested)}</TotalCell>
              <TotalCell numeric={false}>
                <span className="hidden sm:inline" />
              </TotalCell>
              <TotalCell>
                <span className="hidden sm:inline">{inr(summary.totalInvested)}</span>
              </TotalCell>
              <TotalCell>
                <span className="text-violet-300">{percent(summary.ownershipPercent)}</span>
              </TotalCell>
              <TotalCell colSpan={4}>
                <span className="text-slate-400">
                  {percent(summary.progressPercent, 2)} funded
                </span>
              </TotalCell>
            </>
          }
        />
      </Section>
    </div>
  );
}
